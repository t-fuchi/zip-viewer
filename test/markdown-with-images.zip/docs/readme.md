# Doc with Images

![logo](images/logo.png)

Some text after.

![icon](images/icon.png)
