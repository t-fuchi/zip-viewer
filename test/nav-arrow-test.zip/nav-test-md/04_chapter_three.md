# Chapter Three

This is the **fourth** file.

1. Ordered item 1
2. Ordered item 2
3. Ordered item 3

---

Horizontal rule above.
